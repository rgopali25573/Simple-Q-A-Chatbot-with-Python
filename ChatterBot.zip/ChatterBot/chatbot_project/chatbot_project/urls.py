"""URL configuration for chatbot_project project."""
from django.contrib import admin
from django.urls import path, include
from chatbot import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('get-response/', views.get_response, name='get_response'),
]
