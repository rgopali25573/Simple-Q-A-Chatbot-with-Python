from django.shortcuts import render
from django.http import JsonResponse
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

# Create a new chat bot named ChatterBot
bot = ChatBot(
    'ChatterBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    database_uri='sqlite:///database.sqlite3',
    logic_adapters=[
        'chatterbot.logic.MathematicalEvaluation',
        'chatterbot.logic.BestMatch',
    ]
)

# Train the chatbot with English language corpus data
trainer = ChatterBotCorpusTrainer(bot)
trainer.train('chatterbot.corpus.english')


def home(request):
    """
    View function for the home page of the chatbot
    """
    return render(request, 'chatbot/home.html')


def get_response(request):
    """
    View function to get a response from the chatbot
    """
    user_input = request.GET.get('user_input', '')
    
    if user_input:
        response = str(bot.get_response(user_input))
    else:
        response = "Please say something!"
        
    return JsonResponse({'response': response})
