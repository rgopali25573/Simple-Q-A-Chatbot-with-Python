#!/usr/bin/env python3
"""
Terminal Client for ChatBot

This script provides a terminal interface to interact with the ChatBot.
It allows users to have a conversation with the bot directly from the command line.
"""

import os
import sys
import django

# Set up Django environment
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'chatbot_project.settings')
django.setup()

# Import the ChatBot from views
from chatbot.views import bot


def main():
    """
    Main function to run the terminal client
    """
    print("\n===== ChatBot Terminal Client =====\n")
    print("Welcome! I'm ChatterBot, your friendly chatbot.")
    print("Type 'quit', 'exit', or 'bye' to end the conversation.\n")

    # Main conversation loop
    while True:
        # Get user input
        user_input = input("user: ").strip()
        
        # Check if user wants to exit
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("\nbot: Goodbye! Have a great day!")
            break
        
        # Get response from the bot
        try:
            response = str(bot.get_response(user_input))
            print(f"bot: {response}")
        except Exception as e:
            print(f"\nError: {e}")
            print("bot: I'm having trouble understanding. Could you try again?")


if __name__ == "__main__":
    main()