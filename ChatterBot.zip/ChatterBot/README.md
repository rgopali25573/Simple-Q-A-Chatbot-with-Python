# ChatBot

A simple Q&A chatbot built with Django and ChatterBot for the MSCS-633-A01 Advance Artificial Intelligence course.

## Overview

This project implements a terminal-based chatbot using Django and ChatterBot. The chatbot can respond to user queries based on its training data and can be accessed through both a web interface and a terminal client.

## Features

- Web interface for chatting with the bot
- Terminal client for command-line interaction
- Trained on English language corpus
- Supports mathematical evaluations and best match responses

## Requirements

- Python 3.x
- Django
- ChatterBot
- ChatterBot-corpus

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/ChatterBot.git
   cd ChatterBot
   ```

2. Install the required packages:
   ```
   pip install django chatterbot chatterbot-corpus
   ```

3. Navigate to the project directory:
   ```
   cd chatbot_project
   ```

## Usage

### Web Interface

1. Start the Django development server:
   ```
   python manage.py runserver
   ```

2. Open your web browser and go to `http://127.0.0.1:8000/`

3. Start chatting with ChatterBot!

### Terminal Client

1. Run the terminal client script:
   ```
   python terminal_client.py
   ```

2. Start chatting with in the terminal.

3. Type 'quit', 'exit', or 'bye' to end the conversation.

## Project Structure

```
ChatterBot/
├── README.md
├── chatbot_project/
│   ├── chatbot/
│   │   ├── __init__.py
│   │   ├── admin.py
│   │   ├── apps.py
│   │   ├── migrations/
│   │   ├── models.py
│   │   ├── templates/
│   │   │   └── chatbot/
│   │   │       └── home.html
│   │   ├── tests.py
│   │   └── views.py
│   ├── chatbot_project/
│   │   ├── __init__.py
│   │   ├── asgi.py
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── manage.py
│   └── terminal_client.py
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.